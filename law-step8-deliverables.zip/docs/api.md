# 화면 · 서버 요청 · 응답 형식 (F2013)

Django 화면(`web/`)은 화면과 서버를 나눈다.

- 화면: HTML 템플릿, CSS(`web/rag/static/rag/style.css`), JavaScript(`web/rag/static/rag/app.js`).
- 서버: 아래 JSON API. 화면의 JavaScript는 이 API만 부른다.
- 서버는 law 폴더의 RAG 모듈(`collect.py`, `graph.py`, `services.py`)을 그대로 쓴다. Streamlit 화면(`app.py`)과 같은 파이프라인이다.

공통 규칙

| 항목 | 규칙 |
| --- | --- |
| 주소 | `http://127.0.0.1:8000` (실행: `python web/manage.py runserver`) |
| 요청 본문 | JSON 객체, `Content-Type: application/json` |
| 보안 | POST 요청은 `X-CSRFToken` 헤더에 CSRF 토큰을 넣는다 |
| 오류 응답 | `{"error": "사용자용 안내 문장"}`. 키·프롬프트·오류 추적 정보는 넣지 않는다 (NF2004) |
| 상태 코드 | 200 성공, 400 요청 형식 오류, 404 없는 판례, 502 모델·네트워크 오류, 503 색인·키 없음 |

## 1. 판례 목록 — `GET /api/cases/`

응답

```json
{"cases": [
  {"case_id": "619451", "display_name": "[보증금반환] ... · 대법원 2023다307116 (2026)",
   "kind": "상가", "issues": ["보증금반환", "대항력"], "date": "..."}
]}
```

## 2. 질문 — `POST /api/ask/<case_id>/`

`case_id`는 판례일련번호다. 판례 없이 일반 질문을 하면 `general`을 쓴다. 대화 기록은 판례마다 서버 세션에 따로 남는다 (F2009).

요청

```json
{"question": "건물이 팔렸는데 보증금은 누가 돌려주나요?"}
```

응답은 NDJSON이다 (`application/x-ndjson`). 한 줄에 이벤트 하나가 온다. 화면은 이벤트가 올 때마다 진행 상태를 바꾼다 (F2012).

| type | 필드 | 뜻 |
| --- | --- | --- |
| `status` | `text` | 진행 단계. 예) "관련 문서를 찾고 있습니다...", "답변을 만드는 중..." |
| `note` | `text` | 수집 결과. 예) "수집한 문서: 주택임대차보호법 제3조 · ..." |
| `answer` | `answer`, `html`, `sources`, `found`, `not_found` | 최종 답변 |
| `error` | `text` | 답변 실패 안내 |

`answer` 이벤트 예

```json
{"type": "answer",
 "answer": "새 건물주가 보증금 반환 의무를 집니다 [근거 1].",
 "html": "<p>새 건물주가 보증금 반환 의무를 집니다 <span class=\"cite\">근거 1</span>.</p>",
 "sources": [{"n": 1, "label": "판례 메타데이터", "type": "판례",
              "title": "대법원 2023다307116 판결",
              "url": "https://www.law.go.kr/LSW/precInfoP.do?precSeq=619451"}],
 "found": 8, "not_found": false}
```

- `sources`에는 답변이 실제로 인용한 근거만 들어간다 (F2008). 비어 있으면 화면은 "답변에 인용된 근거가 없습니다"를 표시한다.
- `label`은 출처 종류다: 판례 메타데이터 / 법령 / 판결문 (F2007, F2016).
- `found`는 검색한 근거 수, `not_found`는 근거가 없거나 "제공된 문서에서 확인되지 않습니다"로 답한 경우다.

## 3. 판례 찾기 — `POST /api/find/` (F2011)

요청

```json
{"condition": "상가 임차인인데 건물이 팔린 뒤 보증금을 못 받았어요"}
```

응답

```json
{"cases": [
  {"case_id": "619451", "display_name": "...", "kind": "상가", "issues": ["보증금반환"],
   "reason": "건물 양도 뒤 보증금 반환 의무를 다룸", "date": "...",
   "chat_url": "/case/619451/"}
]}
```

조건에 맞는 판례가 없으면 `{"cases": []}`이다. 화면은 카드의 "이 판례로 대화하기"로 `chat_url`을 연다.

## 4. 요건 점검 — `POST /api/check/` (F2010)

요청

```json
{"issue": "대항력", "kind": "주택",
 "situation": "3월 2일에 이사하고 전입신고를 했어요.", "case_id": "general"}
```

- `issue`: 대항력 / 우선변제권 / 보증금반환 / 계약갱신
- `kind`: 주택 / 상가
- `case_id`: 근거로 함께 볼 판례. 없으면 `general` (같은 쟁점의 비슷한 판례 2건을 쓴다)

응답

```json
{"answer": "| 요건 | 내 상황 | 근거 |\n| --- | --- | --- |\n| 주택의 인도 | 3월 2일 이사 | [근거 2] |",
 "html": "<table>...</table>",
 "sources": [{"n": 2, "label": "법령", "type": "법령", "title": "주택임대차보호법 제3조", "url": "https://www.law.go.kr/..."}],
 "found": 5}
```

## 5. 화면 주소

| 주소 | 화면 |
| --- | --- |
| `/` | 질의응답 (일반 질문) |
| `/case/<case_id>/` | 질의응답 (선택한 판례) |
| `/find/` | 판례 찾기 |
| `/check/` | 요건 점검 |

화면 주소는 HTML 틀만 돌려준다. 질문·찾기·점검 결과는 모두 위 API로 받는다.
