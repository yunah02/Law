"""Django 설정. 데이터베이스를 쓰지 않는다 (대화 기록은 파일 세션에 둔다).

DEBUG는 끈다. 오류가 나도 화면에 오류 추적 정보를 보여 주지 않는다 (NF2004).
"""

import os
from pathlib import Path

from django.core.management.utils import get_random_secret_key

WEB_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY") or get_random_secret_key()
DEBUG = os.environ.get("DJANGO_DEBUG") == "1"
ALLOWED_HOSTS = ["127.0.0.1", "localhost"]

INSTALLED_APPS = ["django.contrib.staticfiles", "rag"]
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]
ROOT_URLCONF = "lawsite.urls"
TEMPLATES = [{
    "BACKEND": "django.template.backends.django.DjangoTemplates",
    "DIRS": [],
    "APP_DIRS": True,
    "OPTIONS": {"context_processors": ["django.template.context_processors.request"]},
}]
WSGI_APPLICATION = "lawsite.wsgi.application"
DATABASES = {}

# 판례마다 대화 기록을 세션에 따로 둔다 (F2009). DB 없이 파일에 저장한다
SESSION_ENGINE = "django.contrib.sessions.backends.file"
SESSION_FILE_PATH = str(WEB_DIR / ".sessions")
Path(SESSION_FILE_PATH).mkdir(exist_ok=True)
SESSION_SAVE_EVERY_REQUEST = True

LANGUAGE_CODE = "ko-kr"
TIME_ZONE = "Asia/Seoul"
USE_I18N = False
USE_TZ = True

STATIC_URL = "static/"
STATIC_DIR = WEB_DIR / "rag" / "static"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
