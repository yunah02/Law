from django.conf import settings
from django.urls import include, path, re_path
from django.views.static import serve

urlpatterns = [
    path("", include("rag.urls")),
    # DEBUG를 꺼도 runserver가 CSS·JS를 내보내게 한다 (로컬 실행용)
    re_path(r"^static/(?P<path>.*)$", serve, {"document_root": settings.STATIC_DIR}),
]

handler404 = "rag.views.not_found"
handler500 = "rag.views.server_error"
