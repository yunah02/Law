#!/usr/bin/env python
"""Django 화면 실행 (law 폴더에서):
    python web/manage.py runserver
"""
import os
import sys
from pathlib import Path

WEB_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(WEB_DIR))          # lawsite, rag
sys.path.insert(1, str(WEB_DIR.parent))   # law 폴더의 config.py, graph.py, services.py ...


def main() -> None:
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "lawsite.settings")
    from django.core.management import execute_from_command_line

    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()
