from django.apps import AppConfig


class RagConfig(AppConfig):
    name = "rag"
    verbose_name = "임대차 판례 RAG"
