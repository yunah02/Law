"""Django 화면과 RAG 모듈을 잇는다. 화면 코드는 여기 함수만 부른다.

수집·검색·생성은 law 폴더의 collect.py, retrieval.py, graph.py, services.py가 맡는다 (NF2005).
Streamlit 화면(app.py)과 같은 모듈을 그대로 쓴다.
"""

import html
import os
from functools import lru_cache

import markdown

import config
from data_prep import precedents
from graph import CITE_PATTERN, build_graph, cited_sources
from indexing import get_store
from llm import MissingKeyError, get_chat_model

GENERAL = "general"  # 판례를 고르지 않은 일반 질문의 대화 키
DISCLAIMER = (
    "이 서비스는 공개된 법령과 판례를 바탕으로 한 참고용 정보이며 법률 자문이 아닙니다. "
    "개별 사건의 결론은 사실관계와 적용 시점의 법령에 따라 달라질 수 있습니다. "
    "중요한 결정을 하기 전에 대한법률구조공단, 임대차분쟁조정위원회, 변호사 등 전문가에게 확인하세요."
)


class NotReady(RuntimeError):
    """색인·키·판례 목록이 준비되지 않았을 때. 메시지는 사용자용 안내 문장이다 (F2012)."""


@lru_cache(maxsize=1)
def _resources():
    model = get_chat_model()
    prec_store = get_store(config.PRECEDENT_COLLECTION)
    doc_store = get_store(config.LEGAL_DOC_COLLECTION)
    return model, prec_store, doc_store, build_graph(model, prec_store, doc_store)


def resources():
    """(model, prec_store, doc_store, rag). 준비가 안 되면 NotReady를 낸다."""
    try:
        res = _resources()
    except MissingKeyError:
        raise NotReady("GMS_KEY가 설정되지 않았습니다. law 폴더의 .env 파일에 GMS_KEY를 넣고 서버를 다시 실행하세요.")
    except Exception:
        raise NotReady("Vector DB나 모델을 준비하지 못했습니다. 터미널에서 python indexing.py count 로 상태를 확인하세요.")
    if res[1]._collection.count() == 0:
        _resources.cache_clear()  # 색인한 뒤 서버를 다시 켜지 않아도 되게 한다
        raise NotReady("판례 색인이 0건입니다. 터미널에서 python indexing.py precedents 를 실행한 뒤 새로고침하세요.")
    return res


@lru_cache(maxsize=1)
def _catalog():
    items = precedents.load_items()
    summaries = precedents.load_summaries()
    for it in items:
        it["_name"] = precedents.display_name(it, summaries.get(it["판례일련번호"]))
    return items, {it["판례일련번호"]: it for it in items}


def catalog() -> tuple[list[dict], dict[str, dict]]:
    """(판례 목록, 판례일련번호 → 판례)."""
    try:
        return _catalog()
    except FileNotFoundError:
        raise NotReady("판례 목록(data/items_selected.json)이 없습니다. 터미널에서 python check_precedents.py --reanalyze 를 실행하세요.")


def counts() -> tuple[int, int]:
    _, prec_store, doc_store, _ = resources()
    return prec_store._collection.count(), doc_store._collection.count()


def has_law_oc() -> bool:
    return bool(os.environ.get("LAW_OC"))


def case_info(item: dict) -> dict:
    return {
        "id": item["판례일련번호"], "name": item["_name"], "court": item["법원명"], "date": item["선고일자"],
        "kind": item["구분"], "issues": item["쟁점"], "number": item["사건번호"],
        "url": precedents.source_url(item["판례일련번호"]),
        "holding": item["판시사항"], "summary": item["판결요지"] or "(판결요지 없음)",
    }


# ---------------------------------------------------------------- 답변 표시 (F2008)
def render(text: str) -> str:
    """답변 마크다운을 HTML로 바꾼다. 모델이 쓴 HTML은 글자로만 보이게 먼저 이스케이프한다.
    [근거 N]은 근거 목록과 눈으로 맞춰 볼 수 있게 표시를 붙인다."""
    body = markdown.markdown(html.escape(text, quote=False), extensions=["tables", "sane_lists"])
    return CITE_PATTERN.sub(lambda m: f'<span class="cite">{m.group(0)[1:-1]}</span>', body)


def sources(answer: str, evidence: list[dict]) -> list[dict]:
    """답변이 실제로 인용한 근거만. 세션에 저장하므로 본문은 빼고 표시에 필요한 값만 남긴다."""
    return [{"n": n, "label": ev["label"], "type": ev["source_type"], "title": ev["title"], "url": ev["url"]}
            for n, ev in cited_sources(answer, evidence)]

