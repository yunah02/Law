// 사이드바 판례 목록 필터, 질문 보내기(진행 상태를 한 줄씩 받음), 긴 작업의 진행 표시

(function () {
  // ------------------------------------------------ 판례 목록 필터
  const list = document.getElementById("case-list");
  if (list) {
    const search = document.getElementById("case-search");
    const chips = document.querySelectorAll("#issue-chips .chip");
    const countEl = document.getElementById("case-count");
    let issue = "";
    const apply = () => {
      const q = (search.value || "").trim().toLowerCase();
      let shown = 0;
      list.querySelectorAll("li").forEach((li) => {
        const ok = (!issue || li.dataset.issues.split(" ").includes(issue)) && (!q || li.dataset.text.includes(q));
        li.hidden = !ok;
        if (ok) shown += 1;
      });
      countEl.textContent = shown + "건";
    };
    search.addEventListener("input", apply);
    chips.forEach((chip) => chip.addEventListener("click", () => {
      chips.forEach((c) => c.classList.remove("on"));
      chip.classList.add("on");
      issue = chip.dataset.issue;
      apply();
    }));
    const active = list.querySelector("a.on");
    if (active) active.scrollIntoView({ block: "center" });
  }

  // ------------------------------------------------ 공통 도우미
  const busy = document.getElementById("busy");
  const el = (tag, cls, html) => {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (html !== undefined) node.innerHTML = html;
    return node;
  };
  const text = (s) => { const d = document.createElement("div"); d.textContent = s == null ? "" : String(s); return d.innerHTML; };
  const csrfOf = (form) => form.querySelector("input[name=csrfmiddlewaretoken]").value;
  const sourcesHtml = (sources) => {
    if (!sources.length) return '<p class="no-cite">ⓘ 답변에 인용된 근거가 없습니다.</p>';
    const rows = sources.map((s) =>
      `<li><span class="cite">근거 ${s.n}</span><span class="tag tag-${text(s.type)}">${text(s.label)}</span>` +
      `<span class="src-title">${text(s.title)}</span>` +
      (s.url ? `<a href="${text(s.url)}" target="_blank" rel="noopener">원문</a>` : "") + "</li>").join("");
    return `<details class="sources"><summary>답변에 사용한 근거 ${sources.length}건</summary><ul>${rows}</ul></details>`;
  };

  // JSON API 호출 (F2013). 실패하면 서버가 보낸 안내 문장만 보여 준다
  async function callApi(form, payload) {
    document.getElementById("busy-text").textContent = form.dataset.busy || "처리하는 중...";
    busy.hidden = false;
    const button = form.querySelector("button[type=submit]");
    button.disabled = true;
    try {
      const res = await fetch(form.dataset.url, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-CSRFToken": csrfOf(form) },
        body: JSON.stringify(payload),
      });
      let data = {};
      try { data = await res.json(); } catch (_) { /* 본문이 JSON이 아니면 아래 안내 */ }
      if (!res.ok || data.error) return { error: data.error || "요청을 처리하지 못했습니다. 잠시 뒤 다시 시도해 주세요." };
      return data;
    } catch (_) {
      return { error: "서버와 연결하지 못했습니다. 서버가 실행 중인지 확인해 주세요." };
    } finally {
      busy.hidden = true;
      button.disabled = false;
    }
  }

  // ------------------------------------------------ 판례 찾기 (F2011)
  const findForm = document.getElementById("find-form");
  if (findForm) {
    const out = document.getElementById("find-results");
    findForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const condition = findForm.condition.value.trim();
      if (!condition) return;
      const data = await callApi(findForm, { condition });
      if (data.error) { out.innerHTML = `<p class="alert">${text(data.error)}</p>`; return; }
      if (!data.cases.length) {
        out.innerHTML = '<p class="alert alert-info">조건에 맞는 판례를 찾지 못했습니다. 조건을 바꿔 보세요.</p>';
        return;
      }
      const cards = data.cases.map((c) => `
        <article class="card">
          <p class="eyebrow"><span class="kind kind-${text(c.kind)}">${text(c.kind)}</span> 선고 ${text(c.date)}</p>
          <h3>${text(c.display_name)}</h3>
          <p class="case-meta">${c.issues.map((s) => `<span class="issue">${text(s)}</span>`).join("")}</p>
          <p class="reason"><span>맞는 이유</span>${text(c.reason)}</p>
          <a class="btn btn-ghost" href="${text(c.chat_url)}">이 판례로 대화하기</a>
        </article>`).join("");
      out.innerHTML = `<p class="result-count">조건에 맞는 판례 <strong>${data.cases.length}건</strong></p><div class="cards">${cards}</div>`;
    });
  }

  // ------------------------------------------------ 요건 점검 (F2010)
  const checkForm = document.getElementById("check-form");
  if (checkForm) {
    const out = document.getElementById("check-result");
    checkForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const f = checkForm;
      const data = await callApi(f, {
        issue: f.issue.value, kind: f.querySelector("input[name=kind]:checked").value,
        situation: f.situation.value.trim(), case_id: f.case_id.value,
      });
      if (data.error) { out.innerHTML = `<p class="alert">${text(data.error)}</p>`; return; }
      out.innerHTML = `<section class="msg msg-answer report">
          <div class="who">점검 결과 · 근거 ${data.found}건으로 점검했습니다</div>
          <div class="body answer">${data.html}</div>${sourcesHtml(data.sources)}</section>`;
    });
  }

  // ------------------------------------------------ 질문 보내기
  const composer = document.getElementById("composer");
  if (!composer) return;
  const thread = document.getElementById("thread");
  const input = document.getElementById("question");
  const send = document.getElementById("send");
  const csrf = csrfOf(composer);

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      composer.requestSubmit();
    }
  });

  composer.addEventListener("submit", async (e) => {
    e.preventDefault();
    const question = input.value.trim();
    if (!question) return;
    const empty = document.getElementById("empty");
    if (empty) empty.remove();

    thread.appendChild(el("div", "msg msg-user", `<div class="who">질문</div><div class="body">${text(question).replace(/\n/g, "<br>")}</div>`));
    const box = el("div", "msg msg-answer", '<div class="who">검토 의견</div>');
    const status = el("div", "status", '<span class="spinner"></span> <span class="label">관련 문서를 찾고 있습니다...</span><ul></ul>');
    box.appendChild(status);
    thread.appendChild(box);
    box.scrollIntoView({ behavior: "smooth", block: "end" });
    input.value = "";
    send.disabled = true;

    const fail = (msg) => { status.className = "alert"; status.textContent = msg; };
    try {
      const res = await fetch(composer.dataset.url, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-CSRFToken": csrf },
        body: JSON.stringify({ question }),
      });
      if (!res.ok || !res.body) {
        let msg = "답변을 만들지 못했습니다. 잠시 뒤 다시 시도해 주세요.";
        try { msg = (await res.json()).error || msg; } catch (_) { /* 안내 문장만 보인다 */ }
        fail(msg);
        return;
      }
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      let done = false;
      while (!done) {
        const chunk = await reader.read();
        done = chunk.done;
        buf += decoder.decode(chunk.value || new Uint8Array(), { stream: !done });
        const lines = buf.split("\n");
        buf = lines.pop();
        for (const line of lines) {
          if (!line.trim()) continue;
          const ev = JSON.parse(line);
          if (ev.type === "status") status.querySelector(".label").textContent = ev.text;
          else if (ev.type === "note") status.querySelector("ul").appendChild(el("li", "", text(ev.text)));
          else if (ev.type === "error") fail(ev.text);
          else if (ev.type === "answer") {
            status.querySelector(".spinner").remove();
            status.querySelector(".label").textContent = `근거 ${ev.found}건을 찾아 답변했습니다`;
            if (ev.not_found) box.appendChild(el("p", "alert alert-info", "관련 근거를 찾지 못했습니다. 질문을 바꾸거나 다른 판례를 골라 보세요."));
            box.appendChild(el("div", "body answer", ev.html));
            box.insertAdjacentHTML("beforeend", sourcesHtml(ev.sources));
            const talked = document.querySelector(".case-list a.on");
            if (talked && !talked.querySelector(".talked")) talked.insertAdjacentHTML("beforeend", '<span class="talked">●</span>');
          }
        }
      }
    } catch (_) {
      fail("서버와 연결하지 못했습니다. 서버가 실행 중인지 확인해 주세요.");
    } finally {
      send.disabled = false;
      input.focus();
    }
  });
})();
