from django.urls import path

from . import views

urlpatterns = [
    path("", views.chat, name="chat"),
    path("case/<str:case_id>/", views.chat, name="case"),
    path("api/cases/", views.api_cases, name="api_cases"),
    path("api/ask/<str:case_id>/", views.ask, name="ask"),
    path("api/find/", views.api_find, name="api_find"),
    path("api/check/", views.api_check, name="api_check"),
    path("clear/<str:case_id>/", views.clear, name="clear"),
    path("settings/", views.search_settings, name="settings"),
    path("find/", views.find, name="find"),
    path("check/", views.check, name="check"),
]
