"""화면 (F2009 ~ F2012). Streamlit app.py와 같은 기능을 Django로 만든다.

    /                     질의응답 (판례 없이 일반 질문)
    /case/<판례일련번호>/  질의응답 (선택한 판례로 대화)
    /find/                판례 찾기 (F2011)
    /check/               요건 점검 (F2010)

화면(HTML·CSS·JavaScript)과 서버를 나눈다 (F2013). 화면은 아래 JSON API만 부른다. 형식은 docs/api.md.

    GET  /api/cases/              판례 목록
    POST /api/ask/<판례일련번호>/  질문 → 진행 상태와 답변을 한 줄씩 (NDJSON)
    POST /api/find/               조건 → 맞는 판례
    POST /api/check/              쟁점·상황 → 요건 점검 결과

오류가 나도 사용자용 안내만 보여 주고 키·프롬프트·오류 추적 정보는 보여 주지 않는다 (NF2004).
"""

import json

from django.http import Http404, JsonResponse, StreamingHttpResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_GET, require_POST

import config
from collect import collect
from data_prep.law_api import LawApiError
from graph import NOT_FOUND
from services import ISSUES, check_requirements, find_precedents

from . import backend
from .backend import GENERAL, NotReady

KINDS = ["주택", "상가"]


# ---------------------------------------------------------------- 공통
def _settings(request) -> dict:
    """검색 설정 (F2006, F2014). 세션에 둔다."""
    return request.session.get("search", {"top_k": config.TOP_K, "mmr": config.SEARCH_TYPE == "mmr"})


def _chats(request) -> dict:
    return request.session.setdefault("chats", {})  # 판례일련번호(또는 GENERAL) → 대화 기록 (F2009)


def _page(request, template: str, mode: str, **extra):
    """모든 화면에 공통인 값(판례 목록, 색인 건수, 안내)을 넣어 그린다. 준비가 안 됐으면 안내 화면."""
    try:
        backend.resources()
        items, _ = backend.catalog()
        prec_count, doc_count = backend.counts()
    except NotReady as e:
        return render(request, "rag/not_ready.html", {"message": str(e), "disclaimer": backend.DISCLAIMER})
    chats = _chats(request)
    context = {
        "mode": mode, "disclaimer": backend.DISCLAIMER, "issues": ISSUES,
        "cases": [{"id": it["판례일련번호"], "name": it["_name"], "issues": " ".join(it["쟁점"]),
                   "kind": it["구분"], "talked": bool(chats.get(it["판례일련번호"]))} for it in items],
        "prec_count": prec_count, "doc_count": doc_count, "law_oc": backend.has_law_oc(),
        "search": _settings(request), "current": request.session.get("last_case", GENERAL),
    }
    context.update(extra)
    return render(request, template, context)


def _item(case_id: str | None) -> dict | None:
    if not case_id or case_id == GENERAL:
        return None
    _, by_id = backend.catalog()
    if case_id not in by_id:
        raise Http404
    return by_id[case_id]


# ---------------------------------------------------------------- 질의응답 (F2007 ~ F2009)
def chat(request, case_id: str | None = None):
    try:
        item = _item(case_id)
    except NotReady:
        item = None
    key = item["판례일련번호"] if item else GENERAL
    request.session["last_case"] = key
    messages = [
        {**m, "html": backend.render(m["content"])} if m["role"] == "assistant" else m
        for m in _chats(request).get(key, [])
    ]
    return _page(request, "rag/chat.html", "chat", case=backend.case_info(item) if item else None,
                 key=key, messages=messages)


def _json(request) -> dict:
    """요청 본문(JSON 객체)을 읽는다. 형식이 틀리면 ValueError."""
    data = json.loads(request.body or b"{}")
    if not isinstance(data, dict):
        raise ValueError("JSON 객체가 아닙니다.")
    return data


def _event(kind: str, **data) -> str:
    return json.dumps({"type": kind, **data}, ensure_ascii=False) + "\n"


@require_POST
def ask(request, case_id: str):
    """질문 1개를 처리한다. 진행 상태를 한 줄씩 보내고 마지막에 답변을 보낸다 (F2012)."""
    try:
        question = str(_json(request).get("question", "")).strip()
        model, _, doc_store, rag = backend.resources()
        item = _item(case_id)
    except NotReady as e:
        return JsonResponse({"error": str(e)}, status=503)
    except Http404:
        return JsonResponse({"error": "선택한 판례가 없습니다."}, status=404)
    except ValueError:
        return JsonResponse({"error": "질문을 읽지 못했습니다."}, status=400)
    if not question:
        return JsonResponse({"error": "질문을 입력하세요."}, status=400)

    key = item["판례일련번호"] if item else GENERAL
    history = [{"role": m["role"], "content": m["content"]} for m in _chats(request).get(key, [])]
    search = _settings(request)
    session = request.session

    def stream():
        yield _event("status", text="관련 문서를 찾고 있습니다...")
        notes: list[str] = []
        try:  # 외부 문서 수집 (F2003 ~ F2005)
            report = collect(question, item, model, doc_store, progress=notes.append)
            if report["cached"]:
                yield _event("note", text="이미 수집한 질문이라 수집을 건너뛰었습니다.")
            if report["selected"]:
                yield _event("note", text="수집한 문서: " + " · ".join(report["selected"]))
        except LawApiError:
            yield _event("note", text="법령 문서를 새로 가져오지 못했습니다. 이미 색인된 문서로 답합니다.")
        except Exception:
            yield _event("note", text="문서 수집 중 문제가 생겼습니다. 이미 색인된 문서로 답합니다.")

        yield _event("status", text="답변을 만드는 중...")
        try:
            state = rag.invoke({"question": question, "item": item, "history": history,
                                "top_k": search["top_k"], "search_type": "mmr" if search["mmr"] else "similarity"})
            answer, evidence = state["answer"], state["evidence"]
        except Exception:
            yield _event("error", text="답변을 만들지 못했습니다. 키와 네트워크를 확인한 뒤 다시 시도해 주세요.")
            return

        cited = backend.sources(answer, evidence)
        chats = session.setdefault("chats", {})
        chats.setdefault(key, []).extend([
            {"role": "user", "content": question},
            {"role": "assistant", "content": answer, "sources": cited, "found": len(evidence)},
        ])
        session.modified = True
        session.save()  # 응답을 보내는 중이라 미들웨어가 저장하지 않는다. 직접 저장한다
        yield _event("answer", answer=answer, html=backend.render(answer), sources=cited, found=len(evidence),
                     not_found=not evidence or answer == NOT_FOUND)

    if not session.session_key:
        session.save()
    response = StreamingHttpResponse(stream(), content_type="application/x-ndjson; charset=utf-8")
    response["Cache-Control"] = "no-cache"
    response["X-Accel-Buffering"] = "no"
    return response


@require_POST
def clear(request, case_id: str):
    _chats(request).pop(case_id, None)
    request.session.modified = True
    return redirect("chat" if case_id == GENERAL else "case", **({} if case_id == GENERAL else {"case_id": case_id}))


@require_POST
def search_settings(request):
    try:
        top_k = min(max(int(request.POST.get("top_k", config.TOP_K)), 2), 12)
    except ValueError:
        top_k = config.TOP_K
    request.session["search"] = {"top_k": top_k, "mmr": request.POST.get("mmr") == "on"}
    nxt = request.POST.get("next", "/")
    return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else "/")


# ---------------------------------------------------------------- 판례 찾기 (F2011)
def find(request):
    """화면만 그린다. 찾기는 화면의 JavaScript가 api_find를 부른다 (F2013)."""
    return _page(request, "rag/find.html", "find")


@require_POST
def api_find(request):
    """요청 {"condition": "..."} → 응답 {"cases": [...]} 또는 {"error": "..."} (docs/api.md)."""
    try:
        condition = _json(request).get("condition", "").strip()
        model, prec_store, _, _ = backend.resources()
        _, by_id = backend.catalog()
    except NotReady as e:
        return JsonResponse({"error": str(e)}, status=503)
    except ValueError:
        return JsonResponse({"error": "요청을 읽지 못했습니다."}, status=400)
    if not condition:
        return JsonResponse({"error": "조건을 입력하세요."}, status=400)
    try:
        found = find_precedents(condition, prec_store, model)
    except Exception:
        return JsonResponse({"error": "판례를 찾지 못했습니다. 키와 네트워크를 확인한 뒤 다시 시도해 주세요."}, status=502)
    cases = []
    for card in found:
        item = by_id.get(card["case_id"])
        cases.append({
            "case_id": card["case_id"], "display_name": card["display_name"], "kind": card["kind"],
            "issues": [s for s in card["issues"].split("/") if s], "reason": card["reason"],
            "date": item["선고일자"] if item else "", "chat_url": f"/case/{card['case_id']}/",
        })
    return JsonResponse({"cases": cases}, json_dumps_params={"ensure_ascii": False})


# ---------------------------------------------------------------- 요건 점검 (F2010)
def check(request):
    """화면만 그린다. 점검은 화면의 JavaScript가 api_check를 부른다 (F2013)."""
    form = {"issue": ISSUES[0], "kind": "주택", "case": request.session.get("last_case", GENERAL)}
    if form["case"] != GENERAL:
        try:
            item = _item(form["case"])
            form["kind"] = item["구분"] if item["구분"] in KINDS else "주택"
        except (NotReady, Http404):
            form["case"] = GENERAL
    return _page(request, "rag/check.html", "check", form=form, kinds=KINDS)


@require_POST
def api_check(request):
    """요청 {"issue", "kind", "situation", "case_id"} → 응답 {"answer", "html", "sources", "found"} (docs/api.md)."""
    try:
        data = _json(request)
        issue, kind = data.get("issue", ""), data.get("kind", "")
        situation = str(data.get("situation", "")).strip()
        model, prec_store, doc_store, _ = backend.resources()
        item = _item(data.get("case_id") or GENERAL)
    except NotReady as e:
        return JsonResponse({"error": str(e)}, status=503)
    except Http404:
        return JsonResponse({"error": "선택한 판례가 없습니다."}, status=404)
    except ValueError:
        return JsonResponse({"error": "요청을 읽지 못했습니다."}, status=400)
    if issue not in ISSUES or kind not in KINDS:
        return JsonResponse({"error": "쟁점과 임대차 종류를 확인하세요."}, status=400)
    try:
        answer, evidence = check_requirements(issue, kind, situation, item, model, prec_store, doc_store)
    except Exception:
        return JsonResponse({"error": "요건을 점검하지 못했습니다. 키와 네트워크를 확인한 뒤 다시 시도해 주세요."}, status=502)
    return JsonResponse({"answer": answer, "html": backend.render(answer),
                         "sources": backend.sources(answer, evidence), "found": len(evidence)},
                        json_dumps_params={"ensure_ascii": False})


@require_GET
def api_cases(request):
    """판례 목록 (F2009). 응답 {"cases": [{case_id, display_name, kind, issues, date}]} (docs/api.md)."""
    try:
        items, _ = backend.catalog()
    except NotReady as e:
        return JsonResponse({"error": str(e)}, status=503)
    return JsonResponse({"cases": [{"case_id": it["판례일련번호"], "display_name": it["_name"], "kind": it["구분"],
                                    "issues": it["쟁점"], "date": it["선고일자"]} for it in items]},
                        json_dumps_params={"ensure_ascii": False})


# ---------------------------------------------------------------- 오류 화면 (NF2004)
def not_found(request, exception=None):
    return render(request, "rag/error.html", {"message": "찾는 화면이나 판례가 없습니다.",
                                              "disclaimer": backend.DISCLAIMER}, status=404)


def server_error(request):
    return render(request, "rag/error.html", {"message": "화면을 그리지 못했습니다. 잠시 뒤 다시 시도해 주세요.",
                                              "disclaimer": backend.DISCLAIMER}, status=500)
